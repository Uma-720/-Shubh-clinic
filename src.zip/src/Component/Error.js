export default function Error(){
    return <div className="text-center">
        <img className="m-5" src="error.png" height={400} width={700}></img>
    </div>
}